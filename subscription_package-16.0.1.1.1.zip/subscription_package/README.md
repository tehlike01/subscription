Subscription Package for Community in odoo 16
==============================================
* Subscription Package for Odoo 16 community edition

Installation
============
 - www.odoo.com/documentation/16.0/setup/install.html
 - Install our custom addon

Company
-------
* 'Cybrosys Techno Solutions <https://cybrosys.com/>`__

Contacts
--------
* Mail Contact : odoo@cybrosys.com
* Website : https://cybrosys.com

Credits
--------
* Developer: Amal Prasad @ Cybrosys,
             Archana V   @ Cybrosys

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com

Further information
===================
HTML Description: `<static/description/index.html>`__
